<div id="loading-screen">
    <div id="progress-bar"></div>
    <div class="logo-container">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/better-logo.svg" alt="<?php echo get_bloginfo('name'); ?>">
    </div>
</div>
